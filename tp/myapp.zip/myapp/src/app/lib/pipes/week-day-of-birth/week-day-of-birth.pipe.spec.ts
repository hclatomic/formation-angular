import { WeekDayOfBirthPipe } from './week-day-of-birth.pipe';

describe('WeekDayOfBirthPipe', () => {
  it('create an instance', () => {
    const pipe = new WeekDayOfBirthPipe();
    expect(pipe).toBeTruthy();
  });
});
